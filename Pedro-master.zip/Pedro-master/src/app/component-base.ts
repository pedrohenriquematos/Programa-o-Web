import { Component, OnInit } from '@angular/core';

@Component({
    selector: '',
    templateUrl: '',
    styleUrls: ['']
})

export class ComponentBaseComponent implements OnInit{
    constructor(){}
    ngOnInit(){}
}
