export class Category{
    id: number;
    nome: string;
}