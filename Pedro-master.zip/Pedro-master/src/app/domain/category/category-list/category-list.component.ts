import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'category-list',
    templateUrl: './category-list.component.html',
    styleUrls: ['./category-list.component.css']
})

export class CategoryListCompoment implements OnInit{
    constructor(){}
    ngOnInit(){}
}
