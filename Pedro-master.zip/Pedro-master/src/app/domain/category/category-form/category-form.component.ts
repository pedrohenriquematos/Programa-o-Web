import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'category-form',
    templateUrl: './category-form.component.html',
    styleUrls: ['./category-form.component.css']
})

export class CategoryFormCompoment implements OnInit{
    constructor(){}
    ngOnInit(){}
}
