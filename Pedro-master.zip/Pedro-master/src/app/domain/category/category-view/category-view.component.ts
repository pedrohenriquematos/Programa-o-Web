import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'category-view',
    templateUrl: './category-view.component.html',
    styleUrls: ['./category-view.component.css']
})

export class CategoryViewCompoment implements OnInit{
    constructor(){}
    ngOnInit(){}
}