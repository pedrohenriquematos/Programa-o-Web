export class Categoria{
    id: number;
    nome: String;
}