import {Categoria} from '../categoria/categoria';

export class Produto{
    id: number;
    nome: String;
    preco: number;
    categoria: Categoria;
}