export class Pais{
  id: number;
  nome: string;
  sigla: string;
}
