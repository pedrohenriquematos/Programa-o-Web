import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pais-details',
  templateUrl: './pais-details.component.html',
  styleUrls: ['./pais-details.component.css']
})
export class PaisDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
